
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TransactionsTable from './components/TransactionsTable';
import Statistics from './components/Statistics';
import PriceRangeBarChart from './components/PriceRangeBarChart';

const App = () => {
  const [month, setMonth] = useState('03');  // Default to March
  const [transactions, setTransactions] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [page, setPage] = useState(1);
  const [statistics, setStatistics] = useState({});
  const [priceRangeData, setPriceRangeData] = useState([]);

  // Fetch transactions based on the selected month and searchText
  useEffect(() => {
    const fetchTransactions = async () => {
      const response = await axios.get(`/api/transactions`, {
        params: { month, search: searchText, page }
      });
      setTransactions(response.data);
    };
    fetchTransactions();
  }, [month, searchText, page]);

  // Fetch statistics
  useEffect(() => {
    const fetchStatistics = async () => {
      const response = await axios.get(`/api/statistics`, { params: { month } });
      setStatistics(response.data);
    };
    fetchStatistics();
  }, [month]);

  // Fetch price range data for bar chart
  useEffect(() => {
    const fetchPriceRangeData = async () => {
      const response = await axios.get(`/api/bar-chart`, { params: { month } });
      setPriceRangeData(response.data);
    };
    fetchPriceRangeData();
  }, [month]);

  return (
    <div className="App">
      <h1>Transactions Dashboard</h1>

      {/* Month Selector */}
      <select value={month} onChange={(e) => setMonth(e.target.value)}>
        {['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'].map(m => (
          <option key={m} value={m}>{new Date(0, m - 1).toLocaleString('en', { month: 'long' })}</option>
        ))}
      </select>

      {/* Transactions Table */}
      <TransactionsTable 
        transactions={transactions} 
        searchText={searchText} 
        setSearchText={setSearchText} 
        setPage={setPage}
        page={page}
      />

      {/* Statistics */}
      <Statistics statistics={statistics} />

      {/* Price Range Bar Chart */}
      <PriceRangeBarChart priceRangeData={priceRangeData} />
    </div>
  );
};

export default App;
